package com.boot.tax.calculator.gh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GhanaTaxCalculatorApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GhanaTaxCalculatorApiApplication.class, args);
	}

}
